﻿
Imports System.IO
Imports System.Text

Public Class frmmain

    'Created by: Nevin N.


    'This is a softreset counter

    'This is a simple shinyhunter aid that helps to track softresets, lets you know when you hit odds, files your results, and lets you reload them, also lets you input them


    'The shinymewtwo.txt file attached to this program is an example of how this program saves your softresets and loads them



    'Declares softresets variable, sets it to 0 by default
    Dim softresets As Integer = 0



    'makes sure that the label displays the amount of softresets
    Private Sub frmmain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lbldisresets.Text = softresets.ToString()


    End Sub


    'Exits application
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnaddsoft_Click(sender As Object, e As EventArgs) Handles btnaddsoft.Click

        'adds 1 to the total softresets variable
        softresets += 1
        lbldisresets.Text = softresets.ToString()
        'If the user hits odds (pre gen 6)
        If softresets >= 8192 Then  'Odds in pre gen 6 is 1/8192
            lblodds.ForeColor = Color.Green
            lblodds.Visible = True
        End If

        'If the user hits odds (post gen 6)
        If softresets >= 4096 Then   'odds in post gen6 is 1/4096
            lblodds1.ForeColor = Color.Green
            lblodds1.Visible = True
        End If


        'If the user hits odds (pokemon go)
        If softresets >= 450 Then   'odds in pokmeon go is 1/450
            lblodds2.ForeColor = Color.Green
            lblodds2.Visible = True
        End If


    End Sub

    Private Sub btnsubsoft_Click(sender As Object, e As EventArgs) Handles btnsubsoft.Click
        'subtracts 1 to the total softresets variable
        softresets -= 1
        lbldisresets.Text = softresets.ToString()
    End Sub

    Private Sub btnfile_Click(sender As Object, e As EventArgs) Handles btnfile.Click

        'displays components to user
        btnsave.Visible = True
        txtsave.Visible = True
        lblsave.Visible = True


        'Alerts user of how the data in the file will be deleted
        MsgBox("The file name inputted will overwrite its data." + vbCrLf + "(All other information in the file will be deleted)")


    End Sub

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        If txtsave.Text = "" Then
            'makes sure the user inputs a name 
            MsgBox("Input a file name")

        Else
            'saves the amount of softresets in a file 

            Dim filename As String = txtsave.Text + ".txt"

            'overwrites file 
            Dim file As System.IO.StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(filename, False)
            file.WriteLine(softresets.ToString())
            file.Close()

            MsgBox("Your amount of softresets/encounters has been saved in the file " + filename)




            'makes extra components invisible 
            btnsave.Visible = False
            txtsave.Visible = False
            lblsave.Visible = False
        End If
    End Sub

    Private Sub btnload_Click(sender As Object, e As EventArgs) Handles btnload.Click

        'makes components visible
        btnreget.Visible = True
        txtreget.Visible = True
        lblload.Visible = True

    End Sub

    Private Sub btnreget_Click(sender As Object, e As EventArgs) Handles btnreget.Click


        If txtreget.Text = "" Then
            'makes sure the user inputs a file name 
            MsgBox("Input a filename in the textbox")
        Else

            Dim regeneration As String = txtreget.Text + ".txt"
            Dim softr As String = ""

            If My.Computer.FileSystem.FileExists(regeneration) Then


                Dim file As System.IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader(regeneration)
                softr = file.ReadLine()

                file.Close()



                Integer.TryParse(softr, softresets)   'Sets softresets to the number present in the first line of the file 

                MsgBox("Prior information: " + softresets.ToString())


                'displays softresets to the label
                lbldisresets.Text = softresets.ToString()


                btnreget.Visible = False
                txtreget.Visible = False
                lblload.Visible = False

                MsgBox("Your data has been loaded")
            Else
                MsgBox("The file you have inputted does not exist")

            End If


        End If





    End Sub

    Private Sub btnmanual_Click(sender As Object, e As EventArgs) Handles btnmanual.Click

        'makes components visible
        btninput.Visible = True
        txtinput.Visible = True
        lblinput.Visible = True


        'makes the manual button invisible
        btnmanual.Visible = False
    End Sub



    'Makes the user's input of soft resets the amount of softresets
    Private Sub btninput_Click(sender As Object, e As EventArgs) Handles btninput.Click
        Dim newnum As String = txtinput.Text


        Integer.TryParse(newnum, softresets)


        lbldisresets.Text = softresets.ToString()

        MsgBox("The Softresets have been re-set")


        'makes components invisible
        btninput.Visible = False
        txtinput.Visible = False
        lblinput.Visible = False


        'makes manual button visible
        btnmanual.Visible = True

    End Sub



    'Makes sure the user can only input numbers 
    Private Sub txtinput_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtinput.KeyPress

        e.Handled = (Not Char.IsNumber(e.KeyChar)) And ((e.KeyChar <> ControlChars.Back))

    End Sub

    Private Sub txtinput_KeyDown(sender As Object, e As KeyEventArgs) Handles txtinput.KeyDown
        If e.KeyCode = Keys.Enter Then
            MsgBox("ENTER PRESSED")
        End If

    End Sub
End Class
